# directure/__init__.py

"""
Directure: A tool to explore and visualize directory structures.
"""

__version__ = "0.1.0"
